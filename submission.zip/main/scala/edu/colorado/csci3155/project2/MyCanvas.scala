package edu.colorado.csci3155.project2

/* A class to maintain a canvas. */
import java.awt.geom.{Ellipse2D, Rectangle2D}
import java.awt.{Graphics2D}

/* A figure is a sealed trait. It can be a Polygon or a "MyCircle"*/
sealed trait Figure {
    def getBoundingBox: (Double, Double, Double, Double)
    def translate(shiftX: Double, shiftY: Double): Figure

    def render(g: Graphics2D, scaleX: Double, scaleY: Double, shiftX: Double, shiftY: Double): Unit
}

/*
 Class Polygon
   A polygon is defined by a list of its vertices
 */

case class Polygon(val cList: List[(Double, Double)]) extends Figure {
    //TODONE Define the bounding box of the polygon
    override def getBoundingBox: (Double, Double, Double, Double ) = {
        val cListXY = cList.unzip
        val xmax = cListXY._1.max
        val xmin = cListXY._1.min
        val ymax = cListXY._2.max
        val ymin = cListXY._2.min
        (xmin, xmax, ymin, ymax)
    }
    //TODONE Create a new polygon by shifting each vertex in cList by (x,y)
    //    Do not change the order in which the vertices appear
    override def translate(shiftX: Double, shiftY: Double): Polygon = {
        val newPoly = cList.map(
            xy => (xy._1 + shiftX, xy._2 + shiftY)
        )
        Polygon(newPoly)
    }

    // Function: render -- draw the polygon. Do not edit this function.
    override def render(g: Graphics2D, scaleX: Double, scaleY: Double, shiftX: Double, shiftY: Double) = {
        val xPoints: Array[Int] = new Array[Int](cList.length)
        val yPoints: Array[Int] = new Array[Int](cList.length)
        for (i <- 0 until cList.length){
            xPoints(i) = ((cList(i)._1 + shiftX )* scaleX).toInt
            yPoints(i) = ((cList(i)._2 + shiftY) * scaleY).toInt
        }
        g.drawPolygon(xPoints, yPoints, cList.length)
    }
}

/*
  Class MyCircle
  Define a circle with a given center c and radius r
 */
case class MyCircle(val c: (Double, Double), val r: Double) extends Figure {
    //TODO: Define the bounding box for the circle
    override def getBoundingBox: (Double, Double, Double, Double) = {
        val xmin = c._1 - r
        val xmax = c._1 + r
        val ymin = c._2 - r
        val ymax = c._2 + r
        (xmin, xmax, ymin, ymax)
    }


    //TODO: Create a new circle by shifting the center
    override def translate(shiftX: Double, shiftY: Double): MyCircle = {
        val newC = (c._1 + shiftX, c._2 + shiftY)
        MyCircle(newC, r)
    }

    // Function: render -- draw the polygon. Do not edit this function.
    override def render(g: Graphics2D, scaleX: Double, scaleY: Double, shiftX: Double, shiftY: Double) = {
        val centerX = ((c._1 + shiftX) * scaleX) .toInt
        val centerY = ((c._2 + shiftY) * scaleY) .toInt
        val radX = (r * scaleX).toInt
        val radY = (r * math.abs(scaleY)).toInt
        //g.draw(new Ellipse2D.Double(centerX, centerY, radX, radY))
        g.drawOval(centerX-radX, centerY-radY, 2*radX, 2*radY)
    }
}

/*
  Class : MyCanvas
  Define a canvas through a list of figure objects. Figure objects can be circles or polygons.
 */
class MyCanvas (val listOfObjects: List[Figure]) {
    // TODO: Write a function to get the boundingbox for the entire canvas.
    // Hint: use existing boundingbox functions defined in each figure.
    def getBoundingBox: (Double, Double, Double, Double) = {
        val boundries: List[(Double, Double, Double, Double)] = {
            listOfObjects.map(f => f.getBoundingBox)
        }
        val xmin = boundries.minBy(_._1)._1
        val xmax = boundries.maxBy(_._2)._2
        val ymin = boundries.minBy(_._3)._3
        val ymax = boundries.maxBy(_._4)._4
        (xmin, xmax, ymin, ymax)
    }

    //TODO: Write a function to translate each figure in the canvas by shiftX, shiftY
    def translate(shiftX: Double, shiftY: Double): MyCanvas = {
        val newObjList = listOfObjects.map(f => f.translate(shiftX, shiftY))
        new MyCanvas(newObjList)
    }

    //TODO: Write a function that will return a new MyCanvas object that places
    // all the objects in myc2 to the right of the objects in this MyCanvas.
    // refer to the notebook documentation on how to perform this.
    def placeRight(myc2: MyCanvas):MyCanvas = {
        val c2Bounds = myc2.getBoundingBox
        val origBounds = getBoundingBox
        val xShift = (origBounds._2 - origBounds._1)
        val yShift = (origBounds._4 - origBounds._3)/2 - (c2Bounds._4 - c2Bounds._3)/2
        val newc2 = myc2.translate(xShift, yShift)
        overlap(newc2)
    }

    //TODO: Write a function that will return a new MyCanvas object that places
    // all the figures in myc2 on top of the figures in this MyCanvas.
    // refer to the notebook documentation on how to perform this.
    def placeTop(myc2: MyCanvas): MyCanvas = {
        val c2Bounds = myc2.getBoundingBox
        val origBounds = getBoundingBox
        val xShift = (origBounds._2 - origBounds._1)/2 - (c2Bounds._2 - c2Bounds._1)/2
        val yShift = (origBounds._4 - origBounds._3)
        val newc2 = myc2.translate(xShift, yShift)
        overlap(newc2)
    }

    //TODO: Write a function that will rotate each figure in the canvas using
    // the angle `ang` defined in radians.
    // Suggestion: first write rotation functions for polygon and circle.
    //             those functions have not been added in the classes but you can do so with the
    //             appropriate signature.
    // rotating a polygon is simply rotating each vertex.
    // rotating a circle is simply rotating the center with radius unchanged.
    def rotate(angRad: Double): MyCanvas = {
        val rotatedList:List[Figure] = listOfObjects.map(f => f match {
            case MyCircle(c,r) => {
                val x = (c._1 * math.cos(angRad)) - (c._2 * math.sin(angRad))
                val y = (c._1 * math.sin(angRad)) + (c._2 * math.cos(angRad))
                val newC = (x,y)
                MyCircle(newC, r)
            }
            case Polygon(cList) => {
                val newcList = cList.map(xy => {
                    val x = ((xy._1 * math.cos(angRad)) - (xy._2 * math.sin(angRad)))
                    val y = ((xy._1 * math.sin(angRad)) + (xy._2 * math.cos(angRad)))
                    (x,y)
                })
                Polygon(newcList)
            }
        })
        new MyCanvas(rotatedList)
    }

    // Function to draw the canvas. Do not edit.
    def render(g: Graphics2D, xMax: Double, yMax: Double) = {
        val (lx1, ux1, ly1, uy1) = this.getBoundingBox
        val shiftx = -lx1
        val shifty = -uy1
        val scaleX = xMax/(ux1 - lx1  + 1.0)
        val scaleY = yMax/(uy1 - ly1 + 1.0)
        listOfObjects.foreach(f => f.render(g,scaleX, -scaleY, shiftx, shifty))
    }

    def overlap(c2: MyCanvas): MyCanvas = {
        new MyCanvas(listOfObjects ++ c2.listOfObjects)
    }

    // DO NOT EDIT THE CODE BELOW
    override def toString: String = {
        listOfObjects.foldLeft[String] ("") { case (acc, fig) => acc ++ fig.toString }
    }
    // DO NOT EDIT
    def getListOfObjects: List[Figure] = listOfObjects

    // DO NOT EDIT
    def numPolygons: Int =
        listOfObjects.count {
            case Polygon(_) => true
            case _ => false }

    //DO NOT EDIT
    def numCircles: Int = {
        listOfObjects.count {
            case MyCircle(_,_) => true
            case _ => false }
    }
    //DO NOT EDIT
    def numVerticesTotal: Int = {
        listOfObjects.foldLeft[Int](0) ((acc, f) =>
            f match {
                case Polygon(lst1) => acc + lst1.length
                case _ => acc
            }
        )
    }
}
